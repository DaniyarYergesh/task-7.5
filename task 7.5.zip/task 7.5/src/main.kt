fun main(){
    val triangle: Triangle = Triangle(arrayOf(0,8), arrayOf(1,1), arrayOf(7,5))
    println(triangle.perimeter())
}
