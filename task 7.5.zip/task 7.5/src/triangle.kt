import kotlin.math.abs
import kotlin.math.pow
import kotlin.math.sqrt

class Triangle(val first: Array<Int>, val second: Array<Int>, val third: Array<Int>){

    var a = sqrt(abs(first[0] - second[0]).toDouble().pow(2.0) + abs(first[1] - second[1]).toDouble().pow(2.0))
    var b = sqrt(abs(third[0] - second[0]).toDouble().pow(2.0) + abs(third[1] - second[1]).toDouble().pow(2.0))
    var c = sqrt(abs(first[0] - third[0]).toDouble().pow(2.0) + abs(first[1] - third[1]).toDouble().pow(2.0))

    private var perimeter = a + b + c

    fun print(){
        print("Triangle with vertexes $first, $second, $third")
    }

    fun perimeter(): Double {
        return perimeter
    }

    fun area(): Double {
        val semiP = perimeter/2
        val area = sqrt(semiP*(semiP-a)*(semiP-b)*(semiP-c))
        return area
    }
}
